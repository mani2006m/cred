const express = require("express");
const bodyparser = require("body-parser");
const mongodb = require("mongodb");
const app = express();

app.use(bodyparser.json());

app.use((req, res, next)=>{
    res.setHeader("Access-Control-Allow-Origin", "*")
    res.setHeader("Access-Control-Allow-Headers", "*")
    
    next();
});

var db;

mongodb.connect("mongodb+srv://test:test1@cluster0-l24ac.mongodb.net/test?retryWrites=true&w=majority",
(error, database)=>{
if(error){
    console.log(error)
}

else{
    console.log("MongoDB Connected");
    db = database.db("curedOperation");
}
});

app.post('/register', (req, res)=>{

    console.log(req.body);
    req.body._id = new Date().getTime();

    db.collection('register').save(req.body, (error, data)=>{

        if(error){
            res.status(401).json("Error Database Connection");            
        }
        else{
            res.json("Register Sucessfully");
        }

    })
})

app.post('/login', (req, res)=>{
    console.log(req.body);
    db.collection("register").find(req.body, { projection : {_id:1} }).toArray((error, data)=>{
        if(error){
            res.status(401).json("unable to find the users")
        }
        else{
            res.json(data);
            console.log(data);
        }
    })
});

module.exports = app;