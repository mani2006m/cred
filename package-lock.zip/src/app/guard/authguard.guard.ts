import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CanActivate  } from '@angular/router'
import { LoginserviceService } from '../service/loginservice.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardGuard implements CanActivate {
  
  constructor(public userSer: LoginserviceService, public myRoutes: Router){}

  canActivate() : boolean {

    if(this.userSer.isLoggedIn()) {
      return true;
    }
    else {
      this.myRoutes.navigateByUrl("/login");
      return false;
    }

  }
  
}
