import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from '../app/components/login/login.component';
import { DashboardComponent } from "./components/dashboard/dashboard.component";
import { RegisterComponent } from './components/register/register.component';
import { AuthguardGuard } from './guard/authguard.guard';


const routes: Routes = [
  { path:'', component: LoginComponent },
  { path:'login', component: LoginComponent },
  //{ path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  // { path:'register', component: RegisterComponent },
  { path:'dashboard', component: DashboardComponent, canActivate : [AuthguardGuard] },

  { path:'dashboard/createlist', loadChildren: './components/comp-moudle/comp-moudle.module#CompMoudleModule' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

