import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CompMoudleRoutingModule } from './comp-moudle-routing.module';
import { CreateListComponent } from '../create-list/create-list.component';

@NgModule({
  declarations: [
    CreateListComponent
  ],
  imports: [
    CommonModule,
    CompMoudleRoutingModule
  ]
})
export class CompMoudleModule { }
