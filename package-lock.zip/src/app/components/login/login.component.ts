import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators  } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginserviceService } from 'src/app/service/loginservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  login:FormGroup;
  msg:any;

  constructor(public fb: FormBuilder, public myRoute: Router, public userSer: LoginserviceService) { }

  ngOnInit() {

    this.login = this.fb.group({
      uname: "",
      pass: ""
    })
  }

  userlogin(form:FormGroup){
    //console.log(form.value);
    this.userSer.login(form.value).subscribe((data:any[])=>{
      console.log(data);
      if(data.length>0)
        {
          localStorage.setItem("token", data[0]._id);        
          this.myRoute.navigateByUrl('/dashboard');
        }

        else {
          this.msg = "Invalid User";
          this.login.reset();
          alert(this.msg);
        }  
    },

    (error)=>{
      console.log("Incorrect Users")
    })        
  
  }

  viewPassword(inputpass){
   
    var passStatus = document.getElementById('pass-status');

     if (inputpass.type == 'password') {
      inputpass.type='text';
       passStatus.innerHTML='visibility';
     }
     else {
      inputpass.type='password';
       passStatus.innerHTML='visibility_off';
     }
  }

  registerform() {
    this.myRoute.navigateByUrl("/register");
  }

}


