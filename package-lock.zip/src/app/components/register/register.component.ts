import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginserviceService } from 'src/app/service/loginservice.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  encapsulation: ViewEncapsulation.Emulated  
})

export class RegisterComponent implements OnInit {

  register:FormGroup;
  msg:any;

  constructor(public fb: FormBuilder, public userSer: LoginserviceService, public myRoute: Router) { }

  ngOnInit() {
    this.register = this.fb.group({
      uname: ["", Validators.required],
      email: ["", Validators.required, Validators.maxLength(6)],
      pass: ["", Validators.required]      
    })
  }

  userregister(form:FormGroup){
    console.log(form.value);
    this.userSer.register(form.value).subscribe((data:any)=>{
      console.log(data)
      this.myRoute.navigateByUrl("/login")
    },
    (error)=>{
      console.log(error)
    })

  }

  

}
